blocksworld_ipc
rovers
depot_fix_goals
scanalyzer-08-strips
grid_fix_goals
scanalyzer-opt11-strips
npuzzle_ipc
storage
pipesworld-notankage_fix_goals
transport-opt14-strips
pipesworld-notankage_fix_goals_net
visitall-opt14-strips
Domains and problem instances are from copied from https://zenodo.org/record/3671553 used in the paper
"Neural Network Heuristics for Classical Planning: A Study of Hyperparameter Space". Ferber, Patrick; Helmert, Malte; Hoffmann, Jörg, 2020


blocks-slaney, ferry, gripper, n-puzzle, and zenotravel are taken from https://github.com/williamshen-nz/STRIPS-HGN

barman, spanner, elevators-00-strips, and elevators-opt11-strips are taken from https://github.com/AI-Planning/classical-domains

We have unified the format by removing sub-directories, such that the domain immediately contains the problems. The names of the directories were preserved as prefix of filtes it has contained. For example 
rovers/rovers_p11/p1.pddl become rovers_p11_p1.pddl

